#!/bin/bash

COMPACT_JOB_NAME="${BUILD_ENVIRONMENT}-test"
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

# Required environment variable: $BUILD_ENVIRONMENT
# (This is set by default in the Docker images we build, so you don't
# need to set it yourself.

echo "Testing pytorch"

# JIT C++ extensions require ninja.
git clone https://github.com/ninja-build/ninja --quiet
pushd ninja
python ./configure.py --bootstrap
export PATH="$PWD:$PATH"
popd

# DANGER WILL ROBINSON.  The LD_PRELOAD here oculd cause you problems
# if you're not careful.  Check this if you made some changes and the
# ASAN test is not working
if [[ "$BUILD_ENVIRONMENT" == *asan* ]]; then
    export ASAN_OPTIONS=detect_leaks=0:symbolize=1
    export PYTORCH_TEST_WITH_ASAN=1
    # TODO: Figure out how to avoid hard-coding these paths
    export LD_PRELOAD=/usr/lib/llvm-5.0/lib/clang/5.0.0/lib/linux/libclang_rt.asan-x86_64.so
fi

time python test/run_test.py --verbose

rm -rf ninja

echo "Installing torchvision at branch master"
rm -rf vision
# TODO: This git clone is bad
git clone https://github.com/pytorch/vision --quiet
pushd vision
time python setup.py install
popd

if [[ "$BUILD_TEST_LIBTORCH" == "1" ]]; then
   echo "Testing libtorch with NO_PYTHON"
   LIBTORCH_INSTALL_PREFIX=`pwd`/../libtorch
   pushd tools/cpp_build

   if [[ "$BUILD_ENVIRONMENT" == *cuda* ]]; then
     "$LIBTORCH_INSTALL_PREFIX"/bin/test_jit
   else
     "$LIBTORCH_INSTALL_PREFIX"/bin/test_jit "[cpu]"
   fi
   popd
fi
