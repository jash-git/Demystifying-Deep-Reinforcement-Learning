#include "THCSTensor.h"

#include "generic/THCSTensor.cpp"
#include "THCSGenerateAllTypes.h"
