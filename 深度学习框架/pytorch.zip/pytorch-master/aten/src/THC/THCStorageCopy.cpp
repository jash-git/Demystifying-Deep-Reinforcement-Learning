#include "THCStorageCopy.h"

#include "THCTensorCopy.h"

#include "generic/THCStorageCopy.c"
#include "THCGenerateAllTypes.h"
