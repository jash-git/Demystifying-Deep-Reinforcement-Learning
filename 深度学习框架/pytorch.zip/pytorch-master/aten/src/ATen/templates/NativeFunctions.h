#pragma once

#include "ATen/ATen.h"
#include <tuple>
#include <vector>

namespace at {
namespace native {

${native_function_declarations}

}
}
