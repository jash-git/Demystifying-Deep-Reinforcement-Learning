CLI - Command Line Interface
==============================

.. automodule:: tensorlayer.cli

.. automodule:: tensorlayer.cli.train
