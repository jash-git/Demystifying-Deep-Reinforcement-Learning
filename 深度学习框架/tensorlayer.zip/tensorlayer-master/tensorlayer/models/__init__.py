"""A collections of pre-defined well known models."""

from .vgg16 import VGG16
