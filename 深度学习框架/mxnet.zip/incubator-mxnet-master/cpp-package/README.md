# MXNet C++ Package

To build the C++ package, please refer to [this guide](<https://mxnet.incubator.apache.org/install/build_from_source#build-the-c-package>).

A basic tutorial can be found at <https://mxnet.incubator.apache.org/tutorials/c++/basics.html>.

The example directory contains examples for you to get started. 
