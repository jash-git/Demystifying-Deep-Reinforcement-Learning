# Develop and Hack MXNet
- [Create new operators](new_op.md)
- [Use Torch from MXNet](torch.md)
- [Set environment variables of MXNet](env_var.md)

# Other Resources
- [MXNet System Architecture Overview](http://mxnet.io/architecture/overview.html)
- [Contributor Guidelines](http://mxnet.io/community/contribute.html)