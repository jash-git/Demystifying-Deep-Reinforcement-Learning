# Autoencoders
Get the source code for an example of autoencoders running on MXNet on GitHub in the [autoencoder](https://github.com/dmlc/mxnet/tree/master/example/autoencoder) folder.

## Next Steps
* [MXNet tutorials index](http://mxnet.io/tutorials/index.html)